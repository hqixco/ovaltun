export function initProductGallery() {
  document.querySelectorAll('[data-product-gallery]').forEach((gallery) => {
    const thumbs = Array.from(gallery.querySelectorAll('.product-gallery__thumb'));
    const mainImage = gallery.querySelector('[data-product-gallery-main]');

    if (!thumbs.length || !(mainImage instanceof HTMLImageElement)) return;

    const setActive = (activeThumb) => {
      thumbs.forEach((thumb) => {
        thumb.classList.toggle('product-gallery__thumb--active', thumb === activeThumb);
      });

      const nextSrc = activeThumb.getAttribute('data-full-src');
      const nextAlt = activeThumb.getAttribute('data-full-alt');

      if (nextSrc) {
        mainImage.src = nextSrc;
      }

      if (nextAlt) {
        mainImage.alt = nextAlt;
      }
    };

    thumbs.forEach((thumb) => {
      thumb.addEventListener('click', () => setActive(thumb));
    });

    const activeThumb = thumbs.find((thumb) => thumb.classList.contains('product-gallery__thumb--active')) || thumbs[0];
    if (activeThumb) {
      setActive(activeThumb);
    }
  });
}
