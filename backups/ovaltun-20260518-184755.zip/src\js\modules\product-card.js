export function initProductCardTitles() {
  const cards = Array.from(document.querySelectorAll('.product-card'));
  if (!cards.length) return;

  const updateCard = (card) => {
    const title = card.querySelector('.product-card__title');
    const overlay = card.querySelector('.product-card__title-overlay');

    if (!(title instanceof HTMLElement) || !(overlay instanceof HTMLElement)) return;

    overlay.textContent = title.textContent?.trim() ?? '';
    card.classList.toggle('product-card--title-overflow', title.scrollWidth > title.clientWidth);
  };

  const updateAll = () => {
    cards.forEach(updateCard);
  };

  updateAll();

  if ('ResizeObserver' in window) {
    const resizeObserver = new ResizeObserver(() => {
      updateAll();
    });

    cards.forEach((card) => resizeObserver.observe(card));
    window.addEventListener('resize', updateAll);
  } else {
    window.addEventListener('resize', updateAll);
  }
}
